//preparing the function to get ready
$(document).ready(function() {
    $(".section1").click( function() {
    $(".speakers1").toggle();
  });

  $(".section2").click( function() {
  $(".speakers2").toggle();
  });

  $(".section3").click( function() {
  $(".speakers3").toggle();
  });
});
