  <footer>
    <div class="footer-container">
      <h4>© Flying Pandas 2017 Anisha Amurthur(aa2473),Yi Chen(yc2329),  Jessica Lou(jl2675), Dongqing Wang(dw532)</h4>
      <h4>CREDITES: Icons are designed by Dave Gandy from Flaticon</h4>
      <div class = "footlink">
         <!-- CREDITES: Icons are designed by Dave Gandy from Flaticon"-->
         <a href="https://www.facebook.com/CornellSBA/" target="_blank"><img src="images/facebook.png" alt="Facebook"></a>
         <a href="mailto:sustainablebusinessalliance@gmail.com"><img src="images/mail.png" alt="mail"></a>
      </div>
    </div>
  </footer>
</body>

</html>
