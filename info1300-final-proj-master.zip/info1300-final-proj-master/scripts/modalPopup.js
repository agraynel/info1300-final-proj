// CREDIT: Yi Chen's CS2300 PROJECT 3 CODE

function show_proj_1() {
	document.getElementById('proj_1_popup').style.display = "block";
}

// Hide delete album form popup
function close_proj_1() {
	document.getElementById('proj_1_popup').style.display = "none";
}

function show_proj_2() {
	document.getElementById('proj_2_popup').style.display = "block";
}

// Hide delete album form popup
function close_proj_2() {
	document.getElementById('proj_2_popup').style.display = "none";
}

function show_proj_3() {
	document.getElementById('proj_3_popup').style.display = "block";
}

// Hide delete album form popup
function close_proj_3() {
	document.getElementById('proj_3_popup').style.display = "none";
}
