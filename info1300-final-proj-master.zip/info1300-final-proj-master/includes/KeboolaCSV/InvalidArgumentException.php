<?php
/**
 *
 * User: Martin Halamíček
 * Date: 19.9.12
 * Time: 11:19
 *
 */

namespace Keboola\Csv;

class InvalidArgumentException extends Exception
{

}