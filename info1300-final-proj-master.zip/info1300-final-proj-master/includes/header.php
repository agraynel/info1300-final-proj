<header>
  <figure class="logo">
    <img class="logo" alt="club logo" src="images/logo.png"/>
  </figure>
  <nav>
    <a title="Home" href="index.php"> HOME</a>
    <a title="Board" href="board.php"> BOARD</a>
    <a title="Projects" href="projects.php"> PROJECTS</a>
    <a title="Events" href="events.php">EVENTS</a>
    <a title="Application" href="application.php">APPLICATION</a>
    <a title="Citations" href="citations.php"> CITATION</a>
  </nav>
</header>
