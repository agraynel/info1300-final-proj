<hr>
<footer>
    <div class="footlink">
      <p> Anisha Amurthur(aa2473),Yi Chen(yc2329),Jessica Lou(jl2675), Dongqing Wang(dw532) CREDITS: Icons are designed by Flaticon</p>
      <div class = "footlink">
         <!-- CREDITES: Icons are designed by Dave Gandy from Flaticon"-->
         <a href="https://www.facebook.com/CornellSBA/" target="_blank"><img  class="footimage"src="images/facebook.png" alt="Facebook"></a>
         <a href="mailto:sustainablebusinessalliance@gmail.com"><img  clas="footimage" src="images/mail.png" alt="mail"></a>
      </div>
    </div>
  </footer>
</body>

</html>
