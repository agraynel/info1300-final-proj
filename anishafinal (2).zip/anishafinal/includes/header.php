<!DOCTYPE html>
 <html>
 <head>
   <meta charset="UTF-8">
   <title>Cornell SBA</title>
   <link rel="stylesheet" href="styles/all.css" type="text/css">
   <link rel="icon" href="images/icon.png">
 </head>
 <body>
   <div class="header">
     <div class="row">
       <div class="col">
         <img src="images/logo.png" class="icon" alt="icon">
       </div>
       <div class="col">
        <ul id="navi">
          <li><a title="Home" href="index.php">&raquo; Home</a></li>
          <li><a title="Board" href="board.php">&raquo; Board</a></li>
          <li><a title="Projects" href="projects.php">&raquo; Projects</a></li>
          <li><a title="Events" href="events.php">&raquo; Events</a></li>
          <li><a title="Application" href="application.php">&raquo; Application</a></li>
        </ul>
        </div>
      </div>

      <div class="first_line">
        <input id="search_name" type="text" placeholder=" Your Search Query" name="search_name">
      <input id="submit" class="button" type="submit" name="search_submit" value="Search">

    </div>
      <!-- </div> <br/>
      <div class="second_line">
        <input id="submit" class="button" type="submit" name="search_submit" value="SEARCH">
      </div>
    </div> -->
<!--
          <div class="first_line">
      			<input id="search_name" type="text" placeholder="Name" name="search_name">
            <input id="search_netid" type="text" placeholder="netid" name="search_netid">
            <input id="search_keyword" type="text" placeholder="keyword" name="search_keyword">
      		</div> <br/>
          <div class="second_line">
      			<input id="submit" class="button" type="submit" name="search_submit" value="SEARCH">
      		</div> -->
</div>
